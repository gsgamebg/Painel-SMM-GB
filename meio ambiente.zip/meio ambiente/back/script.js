document.addEventListener('DOMContentLoaded', function () {
    // Gráfico de Dados sobre Resíduos Reciclados
    const ctxResiduos = document.getElementById('myChart').getContext('2d');
    const myChart = new Chart(ctxResiduos, {
        type: 'bar',
        data: {
            labels: ['Plástico', 'Papel', 'Vidro', 'Metal', 'Orgânico'],
            datasets: [{
                label: 'Resíduos Reciclados (em toneladas)',
                data: [500, 300, 200, 100, 400],
                backgroundColor: [
                    'rgba(46, 125, 50, 0.7)', // Verde escuro
                    'rgba(0, 0, 0, 0.7)',     // Preto translúcido
                    'rgba(139, 69, 19, 0.8)', // Marrom translúcido
                    'rgba(100, 100, 100, 0.8)', // Cinza escuro
                    'rgba(76, 175, 80, 0.7)'   // Verde médio
                ],
                borderColor: [
                    'rgba(46, 125, 50, 1)',
                    'rgba(0, 0, 0, 1)',
                    'rgba(139, 69, 19, 1)',   // Borda marrom opaca
                    'rgba(100, 100, 100, 1)',  // Borda cinza
                    'rgba(76, 175, 80, 1)'
                ],
                borderWidth: 2
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#000' // Cor preta para os números do eixo Y
                    }
                },
                x: {
                    ticks: {
                        color: '#000' // Cor preta para os nomes do eixo X
                    }
                }
            },
            plugins: {
                legend: {
                    labels: {
                        color: '#000' // Cor preta para o rótulo da legenda
                    }
                }
            }
        }
    });

    // Gráfico de Coleta de Materiais Recicláveis
    const ctxColeta = document.getElementById('coletaChart').getContext('2d');
    const coletaChart = new Chart(ctxColeta, {
        type: 'pie',
        data: {
            labels: ['Plástico', 'Papel', 'Vidro', 'Metal', 'Orgânico'],
            datasets: [{
                label: 'Materiais Coletados (%)',
                data: [40, 25, 15, 10, 10],
                backgroundColor: [
                    'rgba(46, 125, 50, 0.7)',
                    'rgba(0, 150, 136, 0.7)',
                    'rgba(33, 150, 243, 0.7)',
                    'rgba(255, 193, 7, 0.7)',
                    'rgba(139, 69, 19, 0.7)'
                ],
                borderColor: [
                    'rgba(46, 125, 50, 1)',
                    'rgba(0, 150, 136, 1)',
                    'rgba(33, 150, 243, 1)',
                    'rgba(255, 193, 7, 1)',
                    'rgba(139, 69, 19, 1)'
                ],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        color: '#000',
                        font: {
                            size: 14
                        }
                    }
                }
            }
        }
    });
});
